import { PmtFormData } from '../types';

const STORAGE_KEY = 'pmtDocumentation';

/**
 * Loads PMT documentation data from localStorage
 */
export const loadFromLocalStorage = (): PmtFormData | null => {
  try {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      return JSON.parse(savedData);
    }
  } catch (error) {
    console.error('Error loading data from localStorage:', error);
  }
  return null;
};

/**
 * Saves PMT documentation data to localStorage
 */
export const saveToLocalStorage = (data: PmtFormData): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving data to localStorage:', error);
  }
};

/**
 * Clears PMT documentation data from localStorage
 */
export const clearLocalStorage = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing data from localStorage:', error);
  }
};