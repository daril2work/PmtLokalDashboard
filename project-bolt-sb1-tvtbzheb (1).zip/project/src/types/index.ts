export interface PmtFormData {
  desa: string;
  minggu: string;
  hari: string;
  photos: (string | null)[];
}

export interface PhotoUploaderProps {
  photos: (string | null)[];
  onPhotoChange: (index: number, photo: string | null) => void;
}

export interface FormFieldProps {
  label: string;
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  min?: number;
}

export interface PreviewAreaProps {
  formData: PmtFormData;
  previewRef: React.RefObject<HTMLDivElement>;
  isComplete: boolean;
}

export interface ActionButtonsProps {
  onDownload: (format: 'png' | 'pdf') => void;
  onReset: () => void;
  isComplete: boolean;
  isDownloading: boolean;
}