import React, { useState, useRef, useEffect } from 'react';
import html2canvas from 'html2canvas';
import html2pdf from 'html2pdf.js';
import { Camera } from 'lucide-react';
import FormField from './FormField';
import PhotoUploader from './PhotoUploader';
import PreviewArea from './PreviewArea';
import ActionButtons from './ActionButtons';
import { PmtFormData } from '../types';
import { loadFromLocalStorage, saveToLocalStorage, clearLocalStorage } from '../utils/localStorage';

const DocumentationForm = () => {
  const [formData, setFormData] = useState<PmtFormData>({
    desa: '',
    minggu: '',
    hari: '',
    photos: [null, null, null, null]
  });
  
  const [isDownloading, setIsDownloading] = useState(false);
  const previewRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const savedData = loadFromLocalStorage();
    if (savedData) {
      setFormData(savedData);
    }
  }, []);

  useEffect(() => {
    saveToLocalStorage(formData);
  }, [formData]);

  const handleInputChange = (field: keyof PmtFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePhotoChange = (index: number, photo: string | null) => {
    const updatedPhotos = [...formData.photos];
    updatedPhotos[index] = photo;
    setFormData(prev => ({
      ...prev,
      photos: updatedPhotos
    }));
  };

  const isDataComplete = () => {
    return !!(
      formData.desa && 
      formData.minggu && 
      formData.hari && 
      formData.photos.some(photo => photo !== null)
    );
  };

  const handleDownload = async (format: 'png' | 'pdf' = 'pdf') => {
    if (!isDataComplete()) {
      alert('Harap lengkapi semua data dan minimal unggah satu foto!');
      return;
    }

    if (!previewRef.current) return;
    
    try {
      setIsDownloading(true);
      
      const watermark = document.createElement('div');
      watermark.className = 'absolute bottom-2 right-2 text-gray-400 text-xs';
      watermark.textContent = 'Dokumentasi PMT Ibu Hamil KEK';
      previewRef.current.appendChild(watermark);

      const fileName = `PMT_${formData.desa.replace(/\s+/g, '_')}_Minggu${formData.minggu}_${new Date().toISOString().slice(0,10)}`;
      
      if (format === 'pdf') {
        const opt = {
          margin: 1,
          filename: `${fileName}.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2 },
          jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
        };
        
        await html2pdf().set(opt).from(previewRef.current).save();
      } else {
        const canvas = await html2canvas(previewRef.current, {
          scale: 2,
          logging: false,
          useCORS: true,
          allowTaint: true
        });
        
        const link = document.createElement('a');
        link.download = `${fileName}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
      }
      
      watermark.remove();
      
    } catch (error) {
      console.error('Error generating document:', error);
      alert('Gagal membuat dokumen. Silakan coba lagi.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleReset = () => {
    if (window.confirm('Apakah Anda yakin ingin menghapus semua data?')) {
      setFormData({
        desa: '',
        minggu: '',
        hari: '',
        photos: [null, null, null, null]
      });
      clearLocalStorage();
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow-lg">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <FormField
          label="Desa"
          placeholder="Nama Desa"
          value={formData.desa}
          onChange={(value) => handleInputChange('desa', value)}
        />
        <FormField
          label="Minggu ke"
          placeholder="Minggu ke-"
          value={formData.minggu}
          onChange={(value) => handleInputChange('minggu', value)}
          type="number"
          min={1}
        />
        <FormField
          label="Hari, Tanggal"
          placeholder="Contoh: Senin, 1 Januari 2025"
          value={formData.hari}
          onChange={(value) => handleInputChange('hari', value)}
        />
      </div>

      <PhotoUploader 
        photos={formData.photos} 
        onPhotoChange={handlePhotoChange} 
      />

      <PreviewArea 
        formData={formData} 
        previewRef={previewRef}
        isComplete={isDataComplete()}
      />

      <ActionButtons 
        onDownload={handleDownload}
        onReset={handleReset}
        isComplete={isDataComplete()}
        isDownloading={isDownloading}
      />
    </div>
  );
};

export default DocumentationForm;