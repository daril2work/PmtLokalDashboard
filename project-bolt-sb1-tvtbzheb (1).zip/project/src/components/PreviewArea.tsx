import React from 'react';
import { PreviewAreaProps } from '../types';
import { AlertCircle, Camera } from 'lucide-react';

const PreviewArea: React.FC<PreviewAreaProps> = ({ formData, previewRef, isComplete }) => {
  const { desa, minggu, hari, photos } = formData;
  
  return (
    <div className="mb-8">
      <h3 className="text-lg font-semibold mb-3 text-gray-800 flex items-center">
        Preview Dokumentasi
      </h3>
      
      <div 
        ref={previewRef}
        className="bg-white border-2 border-gray-300 p-6 rounded-lg relative shadow-sm"
      >
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold text-blue-800 mb-2">
            DOKUMENTASI KEGIATAN PMT LOKAL IBU HAMIL KEK
          </h2>
          <p className="text-lg">
            DESA <span className="font-semibold underline">{desa || '________________'}</span>
          </p>
          <p className="text-lg">
            MINGGU KE <span className="font-semibold">{minggu || '_____'}</span>
          </p>
          <p className="text-lg">
            HARI <span className="font-semibold">{hari || '__________________________'}</span>
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {photos.map((photo, i) => (
            <div key={i} className="relative">
              <div className="w-full h-64 border flex items-center justify-center bg-gray-50 rounded-md overflow-hidden">
                {photo ? (
                  <img 
                    src={photo} 
                    alt={`Documentation ${i+1}`} 
                    className="object-contain w-full h-full p-2" 
                  />
                ) : (
                  <div className="text-center text-gray-400">
                    <Camera className="h-12 w-12 mx-auto mb-2" />
                    <span>Dokumentasi</span>
                  </div>
                )}
              </div>
              <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                Foto {i+1}
              </div>
            </div>
          ))}
        </div>
        
        {!isComplete && (
          <div className="text-center mt-6 flex items-center justify-center text-amber-600 text-sm">
            <AlertCircle className="h-4 w-4 mr-1" />
            Lengkapi semua data dan foto untuk hasil terbaik
          </div>
        )}
      </div>
    </div>
  );
};

export default PreviewArea;