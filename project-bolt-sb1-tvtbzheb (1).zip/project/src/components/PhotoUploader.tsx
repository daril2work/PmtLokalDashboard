import React from 'react';
import { Camera, Trash2 } from 'lucide-react';
import { PhotoUploaderProps } from '../types';
import { compressImage } from '../utils/imageUtils';

const PhotoUploader: React.FC<PhotoUploaderProps> = ({ photos, onPhotoChange }) => {
  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const compressedImage = await compressImage(file);
      onPhotoChange(index, compressedImage);
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Error processing image');
      // Reset the input
      event.target.value = '';
    }
  };

  const handleRemovePhoto = (index: number) => {
    if (window.confirm('Hapus foto ini?')) {
      onPhotoChange(index, null);
    }
  };

  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold mb-3 text-gray-800">
        Dokumentasi Foto (Maksimal 4)
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {photos.map((photo, index) => (
          <div key={index} className="flex flex-col items-center">
            <label 
              htmlFor={`photo-${index}`}
              className="w-full h-48 border-2 border-dashed rounded-lg flex items-center justify-center cursor-pointer transition-colors duration-200 hover:bg-gray-50 relative overflow-hidden"
            >
              {!photo ? (
                <div className="text-center p-4">
                  <Camera className="h-10 w-10 mx-auto text-gray-400 mb-2" />
                  <span className="text-sm text-gray-500">Klik untuk unggah</span>
                </div>
              ) : (
                <img 
                  src={photo} 
                  alt={`Foto ${index + 1}`} 
                  className="object-cover w-full h-full transition-opacity duration-200"
                />
              )}
            </label>
            <input
              type="file"
              id={`photo-${index}`}
              accept="image/*"
              className="hidden"
              onChange={(e) => handleFileChange(e, index)}
            />
            {photo && (
              <button
                onClick={() => handleRemovePhoto(index)}
                className="mt-2 text-red-500 text-sm flex items-center hover:text-red-700 transition-colors duration-200"
                aria-label="Hapus foto"
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Hapus
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default PhotoUploader;