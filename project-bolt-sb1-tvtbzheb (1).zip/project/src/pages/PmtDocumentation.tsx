import React from 'react';
import DocumentationForm from '../components/DocumentationForm';

const PmtDocumentation = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Dokumentasi PMT Ibu Hamil KEK</h1>
      <DocumentationForm />
    </div>
  );
};

export default PmtDocumentation;