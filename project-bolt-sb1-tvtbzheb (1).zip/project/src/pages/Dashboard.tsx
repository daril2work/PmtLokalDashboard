import React from 'react';
import { Link } from 'react-router-dom';
import { Camera, FileText, Settings } from 'lucide-react';

const Dashboard = () => {
  const features = [
    {
      icon: Camera,
      title: 'Dokumentasi PMT',
      description: 'Buat dan kelola dokumentasi PMT Ibu Hamil KEK',
      path: '/pmt-documentation'
    },
    {
      icon: FileText,
      title: 'Laporan',
      description: 'Lihat dan unduh laporan kegiatan PMT',
      path: '/reports'
    },
    {
      icon: Settings,
      title: 'Pengaturan',
      description: 'Atur preferensi dan konfigurasi sistem',
      path: '/settings'
    }
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Selamat Datang di PMT Management System</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {features.map((feature) => (
          <Link
            key={feature.path}
            to={feature.path}
            className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200"
          >
            <feature.icon className="w-12 h-12 text-blue-600 mb-4" />
            <h2 className="text-xl font-semibold mb-2">{feature.title}</h2>
            <p className="text-gray-600">{feature.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;