import React from 'react';

const Settings = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Pengaturan</h1>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <p className="text-gray-600">Halaman pengaturan sedang dalam pengembangan.</p>
      </div>
    </div>
  );
};

export default Settings;